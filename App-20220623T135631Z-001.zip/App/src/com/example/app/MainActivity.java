package com.example.app;


import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
   TextView reg;
   Button b,b1;
   EditText eid,epass;
   SQLiteDatabase db;
   String u,p;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	   reg=(TextView)findViewById(R.id.textView4);
	   b=(Button)findViewById(R.id.button1);
	   b1=(Button)findViewById(R.id.button2);
	   eid=(EditText)findViewById(R.id.editText1);
	   epass=(EditText)findViewById(R.id.editText2);
	   db=openOrCreateDatabase("EasyRent",Context.MODE_PRIVATE,null);
	   b.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			if(eid.getText().toString().equals("")||epass.getText().toString().equals(""))
			{
				
				Toast.makeText(MainActivity.this, "PLz enter the fields..!", Toast.LENGTH_LONG).show();
			}
			else
			{	 
				 u = eid.getText().toString();
				 p = epass.getText().toString();
				 try
				 {
				          db=openOrCreateDatabase("EasyRent",SQLiteDatabase.CREATE_IF_NECESSARY,null);					    
				 }
				 catch(Exception exception)
				 {
				            exception.printStackTrace();
				 }
				 try
				 {
					 if(u.equals("admin@gmail.com") && p.equals("admin"))
			        	{
			        		Intent i=new Intent(MainActivity.this,AdminActivity.class);
			        		startActivity(i);
			        	}
					 else{
				        	 Cursor cc = db.rawQuery("select * from Register where id = '"+u+"' and pass = '"+p+"' ", null);
				        	 // User Login
				        	 	if(cc.moveToFirst())
				        		 {
				     			       
					               if (cc != null) 
					            {
					            	if(cc.getCount() > 0)
					            	{
					            	      //return true;
					                      scan g=new scan();
					                       g.execute();
					            
					            		Toast.makeText(MainActivity.this, "Welcome To Home Page "  + u , Toast.LENGTH_SHORT).show();
				            		    cleartext();
					            		Intent i = new Intent(MainActivity.this,NavActivity.class);
					            		startActivity(i);
					            	}
					            }
				        		 }
					            	else
					            	{
					            		 Toast.makeText(MainActivity.this, "Login Failed..!", Toast.LENGTH_LONG).show();
					            	}
					            	
				        		 
				        	
					 } //	return false;
				        }catch(Exception exception){
				            exception.printStackTrace();
				        }
					}	 	
			}

	});
	
reg.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent in=new Intent(MainActivity.this,RegisterActivity.class);
		startActivity(in);
		
	}
});	
}
	private void cleartext() {
		// TODO Auto-generated method stub
		eid.setText("");
		epass.setText("");
		
	}
public class scan extends AsyncTask<String, String, String>{

	private ProgressDialog pd;

	protected void onPreExecute() {
		super.onPreExecute();
	 pd = new ProgressDialog(MainActivity.this);
	 pd.setTitle("Please Wait");
	 pd.setMessage("Logging....");
	 pd.setMax(200);
	 pd.show();
	}
	
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		return null;
	}
	

	
}




}
