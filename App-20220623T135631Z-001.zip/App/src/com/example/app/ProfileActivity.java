package com.example.app;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ProfileActivity extends Activity {
    Button b;
    SQLiteDatabase db;
    String u,p,s;
    EditText eid,pass;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile);
		b=(Button)findViewById(R.id.button1);
		eid=(EditText)findViewById(R.id.editText1);
		pass=(EditText)findViewById(R.id.editText2);
		db=openOrCreateDatabase("EasyRent",Context.MODE_PRIVATE,null);
		b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				 u = eid.getText().toString();
				 p = pass.getText().toString();
				 Cursor c = db.rawQuery("select * from Register where id = '"+u+"' and pass = '"+p+"' ", null);
				 while(c.moveToNext())
					  s=c.getString(4);
				 Cursor cc= db.rawQuery("select * from Details where mobile = '"+s+"'",null);
				 if(c.getCount()==0 && cc.getCount()==0)
		    		{
					 Toast.makeText(ProfileActivity.this, "No data found!!", Toast.LENGTH_SHORT).show();
		    			return;
		    		}	
				 else if(c.getCount()==0 || cc.getCount()==0)
				 {
					 Toast.makeText(ProfileActivity.this, "Invalid Details", Toast.LENGTH_SHORT).show();
		    			return;
				 }
				 else
				 {
				  StringBuffer buffer1=new StringBuffer();
				  StringBuffer buffer=new StringBuffer();
		    		while(c.moveToNext())
		    		{
		    			buffer1.append("Name: "+c.getString(0)+"\n");
		    			buffer1.append("Email id: "+c.getString(1)+"\n");
		    			buffer1.append("Mobile: "+c.getString(4)+"\n");
		    			buffer1.append("--------------------\n");
		    		}
		    		showMessages("Details", buffer1.toString());
		    		while(cc.moveToNext())
		    		{
		    			buffer.append("Marital Status:"+cc.getString(0)+"\n");
		    			buffer.append(cc.getString(1)+"\n");
		    			buffer.append("Type: "+cc.getString(2)+"\n");
		    			buffer.append("Sqft: "+cc.getString(3)+"\n");
		    			buffer.append("Rent: "+cc.getString(4)+"\n");
		    			buffer.append("Address: "+cc.getString(5)+"\n");
		    			buffer.append("--------------------------------------------------\n");
		    		}
		    		showMessage("  Your Specifications", buffer.toString());
		    		return;
				 }
			}
		});
	}

	protected void showMessage(String string, String string2) {
		// TODO Auto-generated method stub
		AlertDialog.Builder builder=new AlertDialog.Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(string);
    	builder.setMessage(string2);
    	builder.show();
		
	}
	protected void showMessages(String string, String string2) {
		// TODO Auto-generated method stub
		AlertDialog.Builder builder=new AlertDialog.Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(string);
    	builder.setMessage(string2);
    	builder.show();
		
	}

}
