package com.example.app;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PropertyActivity extends Activity {
  Button b;
  EditText e1,e2,e3,e4,e5,e6,e7;
    SQLiteDatabase db;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_property);
		b=(Button)findViewById(R.id.button1);
		e1=(EditText)findViewById(R.id.editText1);
		e2=(EditText)findViewById(R.id.editText2);
		e3=(EditText)findViewById(R.id.editText3);
		e4=(EditText)findViewById(R.id.editText4);
		e5=(EditText)findViewById(R.id.editText5);
		e6=(EditText)findViewById(R.id.editText6);
		e7=(EditText)findViewById(R.id.editText7);
		db=openOrCreateDatabase("EasyRent",Context.MODE_PRIVATE,null);
		db.execSQL("create table if not exists Details(marital_status varchar,bedrooms varchar,type varchar,sqft varchar,rent varchar,address varchar,mobile varchar);");
		b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(e1.getText().toString().equals("") ||
		           e2.getText().toString().equals("") ||
				   e3.getText().toString().equals("") ||
				   e4.getText().toString().equals("") ||
				   e5.getText().toString().equals("") ||
				   e6.getText().toString().equals("") ||
				   e7.getText().toString().equals(""))
				{
					Toast.makeText(PropertyActivity.this,"enter valid data",Toast.LENGTH_SHORT).show();
					return;
				}
				else if(e7.getText().toString().trim().length()!=10)
				{
				  Toast.makeText(PropertyActivity.this,"enter valid mobile number",Toast.LENGTH_SHORT).show();
				  return;
				}
				else
				{
					db.execSQL("insert into Details values('" +e1.getText()+"','"+e2.getText()+"','"+e3.getText()+"','"+e4.getText()+"','"+e5.getText()+"','"+e6.getText()+"','"+e7.getText()+"');");
				    Toast.makeText(PropertyActivity.this,"Submitted successfully!!",Toast.LENGTH_SHORT).show();
				    cleartext();
				}
			}
		});
	}

	protected void cleartext() {
		// TODO Auto-generated method stub
		e1.setText("");
		e2.setText("");
		e3.setText("");
		e4.setText("");
		e5.setText("");
		e6.setText("");
		e7.setText("");
	}

}
