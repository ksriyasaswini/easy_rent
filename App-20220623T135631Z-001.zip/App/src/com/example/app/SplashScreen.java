package com.example.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;

public class SplashScreen extends Activity {
	
	private boolean backbtnPress;
	private static final int SPLASH_DURATION=3000;
	private Handler myHandler;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
		//getActionBar().hide();
		setContentView(R.layout.activity_splshscreen);
	    myHandler = new Handler();
	    myHandler.postDelayed(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
			 finish();
			 if(!backbtnPress)
			 {
				 Intent i = new Intent(SplashScreen.this,MainActivity.class);
			     SplashScreen.this.startActivity(i);
			 }
			}
		}, SPLASH_DURATION);
	}
 @Override
public void onBackPressed() {
	// TODO Auto-generated method stub
	backbtnPress=true;
	
	super.onBackPressed();
}
}
