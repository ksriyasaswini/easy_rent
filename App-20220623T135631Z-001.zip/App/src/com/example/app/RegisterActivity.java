package com.example.app;

import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends Activity {
	Button b,b1;
	EditText ename,eid,pass,conpass,mobile;
	ImageView img;
	SQLiteDatabase db;
	byte[] data;
	final int RESULT_LOAD_IMAGE = 1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);
		
		ename=(EditText)findViewById(R.id.editText5);
		eid=(EditText)findViewById(R.id.editText1);
		pass=(EditText)findViewById(R.id.editText2);
		conpass=(EditText)findViewById(R.id.editText3);
		mobile=(EditText)findViewById(R.id.editText4);
		b=(Button)findViewById(R.id.button1);
		b1=(Button)findViewById(R.id.button2);
		img=(ImageView)findViewById(R.id.imgView);
		db=openOrCreateDatabase("EasyRent",Context.MODE_PRIVATE,null);
		db.execSQL("create table if not exists Register(name varchar,id varchar,pass varchar,conpass varchar,mobile varchar,img blob);");
		b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				if(ename.getText().toString().equals("") ||
				   eid.getText().toString().equals("") ||
				   pass.getText().toString().equals("")||
				   conpass.getText().toString().equals("") ||
				   mobile.getText().toString().equals("") )
				{
					Toast.makeText(RegisterActivity.this,"enter valid data",Toast.LENGTH_SHORT).show();
					return;
				}
				else if(mobile.getText().toString().trim().length()!=10)
				{
				  Toast.makeText(RegisterActivity.this,"enter valid mobile number",Toast.LENGTH_SHORT).show();
				  return;
				}
				else if(!pass.getText().toString().equals(conpass.getText().toString()))
				{
					Toast.makeText(RegisterActivity.this,"password mismatch",Toast.LENGTH_SHORT).show();
					return;
				}
				else
				{
					db.execSQL("insert into Register values('" +ename.getText()+"','"+eid.getText()+"','"+pass.getText()+"','"+conpass.getText()+"','"+mobile.getText()+"','"+data+"');");
				    Toast.makeText(RegisterActivity.this,"registered successfully!!",Toast.LENGTH_SHORT).show();
				    cleartext();
				    Intent in=new Intent(RegisterActivity.this,MainActivity.class);
				    startActivity(in);	
				}
			}

		});
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(
						Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
						
						startActivityForResult(i, RESULT_LOAD_IMAGE);
			}
		});

	}

	
	private void cleartext() {
		// TODO Auto-generated method stub
		ename.setText("");
		eid.setText("");
		pass.setText("");
		conpass.setText("");
		mobile.setText("");
		
		
	}
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	super.onActivityResult(requestCode, resultCode, data);
    	
		if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
			Uri selectedImage = data.getData();
			String[] filePathColumn = { MediaStore.Images.Media.DATA };

			Cursor cursor = getContentResolver().query(selectedImage,
					filePathColumn, null, null, null);
			cursor.moveToFirst();

			int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
			String picturePath = cursor.getString(columnIndex);
			cursor.close();
			
			ImageView imageView = (ImageView) findViewById(R.id.imgView);
			imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
		
		}
    
    
    }

}
