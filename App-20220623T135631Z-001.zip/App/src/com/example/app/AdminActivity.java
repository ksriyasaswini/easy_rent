package com.example.app;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdminActivity extends Activity {
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.admin);
		Button b1,b2,b3,b4,b5;
		final EditText t;
		final EditText t1;
		final SQLiteDatabase db1;
		 b1=(Button)findViewById(R.id.button1);
		 b2=(Button)findViewById(R.id.button2);
		 b3=(Button)findViewById(R.id.button3);
		 b4=(Button)findViewById(R.id.button4);
		 b5=(Button)findViewById(R.id.button5);
		 t=(EditText)findViewById(R.id.editText2);
		 t1=(EditText)findViewById(R.id.editText1);
		 db1=openOrCreateDatabase("EasyRent",Context.MODE_PRIVATE,null);
		 b2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			Cursor c = db1.rawQuery("select * from Register ", null);
			if(c.getCount()==0)
    		{
			 Toast.makeText(AdminActivity.this, "No data found!!", Toast.LENGTH_SHORT).show();
    			return;
    		}	
			else
			 {
			  StringBuffer buffer1=new StringBuffer();
	    		while(c.moveToNext())
	    		{
	    			buffer1.append("Name: "+c.getString(0)+"\n");
	    			buffer1.append("Email id: "+c.getString(1)+"\n");
	    			buffer1.append("Mobile: "+c.getString(4)+"\n");
	    			buffer1.append("------------------------------\n");
	    		}
	    		showMessages("Details", buffer1.toString());
			 }
			}
		});
		 b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Cursor c = db1.rawQuery("select * from Details ", null);
				if(c.getCount()==0)
	    		{
				 Toast.makeText(AdminActivity.this, "No data found!!", Toast.LENGTH_SHORT).show();
	    			return;
	    		}	
				else
				 {
				  StringBuffer buffer1=new StringBuffer();
		    		while(c.moveToNext())
		    		{
		    			buffer1.append("Will be given to : "+c.getString(0)+"\n");
		    			buffer1.append(c.getString(1)+"\n");
		    			buffer1.append("Type: "+c.getString(2)+"\n");
		    			buffer1.append("Sqft: "+c.getString(3)+"\n");
		    			buffer1.append("Rent: "+c.getString(4)+"\n");
		    			buffer1.append("Address: "+c.getString(5)+"\n");
		    			buffer1.append("Mobile: "+c.getString(6)+"\n");
		    			buffer1.append("------------------------------\n");
		    		}
		    		showMessages("properties", buffer1.toString());
				 }
				
			}
		});
		 b3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(t1.getText().toString().equals(""))
					Toast.makeText(AdminActivity.this,"Enter email id",Toast.LENGTH_SHORT).show();
				else{
				db1.execSQL("delete from Details where address='"+t1.getText()+"'");
				Toast.makeText(AdminActivity.this,"Deleted sucessfully",Toast.LENGTH_SHORT).show();
				}
			}
		});
		 b4.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(t.getText().toString().equals(""))
					Toast.makeText(AdminActivity.this,"Enter email id",Toast.LENGTH_SHORT).show();
				else{
				db1.execSQL("delete from Register where id='"+t.getText()+"'");
				Toast.makeText(AdminActivity.this,"Deleted sucessfully",Toast.LENGTH_SHORT).show();
				}
			}
		});
		 b5.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i=new Intent(AdminActivity.this,MainActivity.class);
				startActivity(i);
			}
		});
		 
	}

	protected void showMessages(String string, String string2) {
		// TODO Auto-generated method stub
		AlertDialog.Builder builder=new AlertDialog.Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(string);
    	builder.setMessage(string2);
    	builder.show();
	}


}
