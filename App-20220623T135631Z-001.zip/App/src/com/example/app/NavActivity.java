package com.example.app;


import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class NavActivity extends Activity {
	  Button b1,b2,b3;
	  EditText t;
	  ImageButton b;
	  SQLiteDatabase db;
		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.nav);
			b=(ImageButton)findViewById(R.id.imageButton1);
			b1=(Button)findViewById(R.id.button1);
			b2=(Button)findViewById(R.id.button2);
			b3=(Button)findViewById(R.id.button3);
			t=(EditText)findViewById(R.id.editText1);
			db=openOrCreateDatabase("EasyRent",Context.MODE_PRIVATE,null);
			b.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Cursor c = db.rawQuery("select * from Details where address like '%"+t.getText()+"%'", null);
					if(c.getCount()==0)
		    		{
					 Toast.makeText(NavActivity.this, "No data found!!", Toast.LENGTH_SHORT).show();
		    			return;
		    		}	
					else
					{
						StringBuffer buffer=new StringBuffer();
					while(c.moveToNext())
		    		{
		    			buffer.append("Marital Status:"+c.getString(0)+"\n");
		    			buffer.append(c.getString(1)+"\n");
		    			buffer.append("Mobile: "+c.getString(2)+"\n");
		    			buffer.append("Sqft: "+c.getString(3)+"\n");
		    			buffer.append("Rent: "+c.getString(4)+"\n");
		    			buffer.append("Address: "+c.getString(5)+"\n");
		    			buffer.append("Mobile:"+c.getString(6)+"\n\n");
		    		}
					showMessage("List according to ur location", buffer.toString());
		    		return;
				}
				}
			});
			b2.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent i=new Intent(NavActivity.this,PropertyActivity.class);
					startActivity(i);
					
				}
			});
			b1.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent i=new Intent(NavActivity.this,ProfileActivity.class);
					startActivity(i);
					}
					
				
			});

	        b3.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent i=new Intent(NavActivity.this,MainActivity.class);
					startActivity(i);
				}
			});
		}

		protected void showMessage(String string, String string2) {
			// TODO Auto-generated method stub
			AlertDialog.Builder builder=new AlertDialog.Builder(this);
	    	builder.setCancelable(true);
	    	builder.setTitle(string);
	    	builder.setMessage(string2);
	    	builder.show();
			
		}

		

	}
